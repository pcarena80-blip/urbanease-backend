const mongoose = require('mongoose');

const carpoolSchema = new mongoose.Schema({
    provider: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true
    },
    name: { // Snapshot of provider name for easier display
        type: String,
        required: true
    },
    contactNumber: {
        type: String,
        required: true
    },
    vehicleType: {
        type: String,
        required: true,
        enum: ['Car', 'Bike', 'Van', 'Other']
    },
    vehicleNumber: {
        type: String,
        required: true
    },
    seatingCapacity: {
        type: Number,
        required: true,
        max: 4 // Enforce max 4 seats
    },
    seatsAvailable: {
        type: Number,
        required: true,
        max: 4
    },
    schedule: {
        type: [{
            day: { type: String, required: true },
            time: { type: String, required: true }
        }],
        required: true
    },
    pickupLocation: {
        type: String,
        required: true
        // Default removed to allow user input
    },
    destination: {
        type: String,
        required: false
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Carpool', carpoolSchema);
